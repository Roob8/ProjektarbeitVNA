from distutils.core import setup

setup(
    name = 'vnakit',
    version = '1.0.11',
    description = 'VNAKit for VNA demonstrations and exercises',
    author='Vayyar',
    author_email='support@vayyar.com',
    url='http://vayyar.com/',
    classifiers=['Programming Language :: Python :: 2', 'Programming Language :: Python :: 3'],
    py_modules=['vnakit']
)
